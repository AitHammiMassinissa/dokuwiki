const IPFS     = require('ipfs-mini');
var shell_exec = require('shell_exec').shell_exec;


const ipfs     = new IPFS({host: 'ipfs.infura.io', port: 5001, protocol: 'https'});
const data     = "test2";
ipfs.add(data, (err, hash)=>{
	if(err)
	{
		return console.log(err);
	}
	console.log('https://ipfs.infura.io/ipfs/'+hash);
				
})


